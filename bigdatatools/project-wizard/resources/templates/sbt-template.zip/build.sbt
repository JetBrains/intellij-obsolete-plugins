ThisBuild / version := "1.0.0-SNAPSHOT"

ThisBuild / scalaVersion := "$$$SCALA_FULL_VERSION"

lazy val root = (project in file("."))
  .settings(
    name := "$$$ARTIFACT"
  )


val sparkVersion = "$$$SPARK_VERSION"

libraryDependencies ++= Seq(
  "org.apache.spark" %% "spark-core" % sparkVersion,
  "org.apache.spark" %% "spark-sql" % sparkVersion,
  "org.apache.spark" %% "spark-mllib" % sparkVersion,
  "org.apache.spark" %% "spark-streaming" % sparkVersion
)

